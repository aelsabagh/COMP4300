#include <stdio.h>
#include <math.h>
#include "mpi.h"

#define A(I,J) a[(I) + ((J))* ( m)]
#define B(I,J) b[(I) + ((J))* ( k)]
#define C(I,J) c[(I) + ((J))* ( m)]

int mult_replicated(int m, int n, int k, double* a, double* b, double* c) {
    // distribute matrices A, B

    // replace with your distributed matrix multiplication code
    int i,j,l;
    for (i=0; i<m; i++) {
        for(j=0;j<n;j++) {
            C(i,j) = 0.0;
            for(l=0;l<k;l++) {
                C(i,j) += A(i,l) * B(l,j);
            }
        }
    }

    // gather matrix C at process 0

    return 0;
}

/* Perform distributed matrix multiplication using provided code for the SUMMA algorithm. */
int mult_summa(int m, int n, int k, double* a, double* b, double* c) {
    // distribute matrices and create communicators
    // pdgemm(...);
    // gather matrix C at process 0
    return 0;
}


